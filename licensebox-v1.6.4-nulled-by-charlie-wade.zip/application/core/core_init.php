<?php

if (!(count(get_included_files()) == 1)) {
    define("atSEXsTF", true);
    define("lbI3Kt1y", true);
    define("DlgP6FRs", "Connection to server failed or the server returned an error, please contact support.");
    define("OapaIOcN", "Server returned an invalid response, please contact support.");
    define("tHaXM0ad", "Verified! Thanks for purchasing.");
    define("e_UjjApQ", "Preparing to download main update...");
    define("KpDqQC9y", "Main Update size:");
    define("St4qVvxE", "(Please do not refresh the page).");
    define("WeogxcvY", "Downloading main update...");
    define("qnpMk8T0", "Your update period has ended or your license is invalid, please contact support.");
    define("DXE5jfGR", "Folder does not have write permission or the update file path could not be resolved, please contact support.");
    define("fwbqHPu0", "Main update files downloaded and extracted.");
    define("zCxijzKj", "Update zip extraction failed.");
    define("Krr9HvME", "Preparing to download SQL update...");
    define("RfxN84X4", "SQL Update size:");
    define("VOz6qFzC", "Downloading SQL update...");
    define("tWLVMDua", "SQL update files downloaded.");
    define("KizAdDH4", "SQL updates could not be imported, please import it manually.");
    define("UrNTGMos", "Update successful, SQL updates were successfully imported.");
    define("eC9iiUrH", "Update successful, there were no SQL updates. So you can run the updated application directly.");
    if (atSEXsTF) {
        goto DOseefRb;
    }
    @ini_set("display_errors", 0);
    DOseefRb:
    if (!(@ini_get("max_execution_time") !== "0" && @ini_get("max_execution_time") < 600)) {
        goto eXT1hp1k;
    }
    @ini_set("max_execution_time", 600);
    eXT1hp1k:
    @ini_set("memory_limit", "256M");
    class L1c3n5380x4P1
    {
        private $product_id;
        private $api_url;
        private $api_key;
        private $api_language;
        private $current_version;
        private $verify_type;
        private $verification_period;
        private $current_path;
        private $root_path;
        private $license_file;
        public function __construct()
        {
            $this->product_id = "B2A17YLB";
            $this->api_url = "";
            $this->api_key = "";
            $this->api_language = "english";
            $this->current_version = "v1.6.4";
            $this->verify_type = "non_envato";
            $this->verification_period = 3;
            $this->current_path = realpath("/var/www/html");
            $this->root_path = realpath($this->current_path . "/../..");
            $this->license_file = realpath($this->current_path) . "/.lb_lic";
        }
        public function check_local_license_exist()
        {
            return is_file($this->license_file);
        }
        public function get_current_version()
        {
            return $this->current_version;
        }
        private function call_api($xDRS_fkd, $soMDpLl_, $OCyiNPLL)
        {
            if (!(session_status() == PHP_SESSION_NONE)) {
                goto OyJxZkf5;
            }
            OyJxZkf5:
            if (!empty($_SESSION["UHhd87HJKtJ"])) {
                goto AwiTgmDJ;
            }
            $_SESSION["UHhd87HJKtJ"] = 0;
            AwiTgmDJ:
            $ZX2L6jpC = curl_init();
            switch ($xDRS_fkd) {
                case "POST":
                    curl_setopt($ZX2L6jpC, CURLOPT_POST, 1);
                    if (!$OCyiNPLL) {
                        goto JKgq4QJo;
                    }
                    curl_setopt($ZX2L6jpC, CURLOPT_POSTFIELDS, $OCyiNPLL);
                    JKgq4QJo:
                    goto fOTClHp_;
                case "PUT":
                    curl_setopt($ZX2L6jpC, CURLOPT_CUSTOMREQUEST, "PUT");
                    if (!$OCyiNPLL) {
                        goto lT4eaU5y;
                    }
                    curl_setopt($ZX2L6jpC, CURLOPT_POSTFIELDS, $OCyiNPLL);
                    lT4eaU5y:
                    goto fOTClHp_;
                default:
                    if (!$OCyiNPLL) {
                        goto CPAQUCxW;
                    }
                    $soMDpLl_ = sprintf("%s?%s", $soMDpLl_, http_build_query($OCyiNPLL));
                    CPAQUCxW:
            }
            fOTClHp_:
            $W90Io60R = ((getenv("SERVER_NAME") ?: $_SERVER["SERVER_NAME"]) ?: getenv("HTTP_HOST")) ?: $_SERVER["HTTP_HOST"];
            $n68Kseqp = (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on" or isset($_SERVER["HTTP_X_FORWARDED_PROTO"]) and $_SERVER["HTTP_X_FORWARDED_PROTO"] === "https") ? "https://" : "http://";
            $shck3_tM = $n68Kseqp . $W90Io60R . $_SERVER["REQUEST_URI"];
            $z6mftJs8 = ((getenv("SERVER_ADDR") ?: $_SERVER["SERVER_ADDR"]) ?: $this->get_ip_from_third_party()) ?: gethostbyname(gethostname());
            curl_setopt($ZX2L6jpC, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "LB-API-KEY: " . $this->api_key, "LB-URL: " . $shck3_tM, "LB-IP: " . $z6mftJs8, "LB-LANG: " . $this->api_language));
            curl_setopt($ZX2L6jpC, CURLOPT_URL, $soMDpLl_);
            curl_setopt($ZX2L6jpC, CURLOPT_RETURNTRANSFER, true);
            if (!($_SESSION["UHhd87HJKtJ"] >= 3)) {
                goto HhTLVoN8;
            }
            curl_setopt($ZX2L6jpC, CURLOPT_PROXY, $this->get_proxy_from_third_party());
            curl_setopt($ZX2L6jpC, CURLOPT_HTTPPROXYTUNNEL, 1);
            HhTLVoN8:
            curl_setopt($ZX2L6jpC, CURLOPT_CONNECTTIMEOUT, 30);
            curl_setopt($ZX2L6jpC, CURLOPT_TIMEOUT, 30);
            $orHsq_Th = curl_exec($ZX2L6jpC);
            if (!$orHsq_Th && curl_errno($ZX2L6jpC)) {
                $_SESSION["UHhd87HJKtJ"] += 1;
                goto rpHuQlBk;
            }
            unset($_SESSION["UHhd87HJKtJ"]);
            rpHuQlBk:
            if (!(!$orHsq_Th && !atSEXsTF)) {
                $Dt00z81_ = curl_getinfo($ZX2L6jpC, CURLINFO_HTTP_CODE);
                if (!($Dt00z81_ != 200)) {
                    KZfPTJ0R:
                    curl_close($ZX2L6jpC);
                    return $orHsq_Th;
                }
                if (atSEXsTF) {
                    $AJLpZ7ov = json_decode($orHsq_Th, true);
                    $lZrvIl0z = array("status" => false, "message" => !empty($AJLpZ7ov["error"]) ? $AJLpZ7ov["error"] : $AJLpZ7ov["message"]);
                    return json_encode($lZrvIl0z);
                }
                $lZrvIl0z = array("status" => false, "message" => OapaIOcN);
                return json_encode($lZrvIl0z);
            }
            $lZrvIl0z = array("status" => false, "message" => DlgP6FRs);
            return json_encode($lZrvIl0z);
        }
        public function check_connection()
        {
            $mvQ3GjtN = array();
            $UhYdRty6 = $this->call_api("POST", $this->api_url . "api/check_connection_ext", json_encode($mvQ3GjtN));
            $uET9scFl = json_decode($UhYdRty6, true);
            return $uET9scFl;
        }
        public function get_latest_version()
        {
            $mvQ3GjtN = array("product_id" => $this->product_id);
            $UhYdRty6 = $this->call_api("POST", $this->api_url . "api/latest_version", json_encode($mvQ3GjtN));
            $uET9scFl = json_decode($UhYdRty6, true);
            return $uET9scFl;
        }
        public function activate_license($uVpML53d, $fC1F3kK2, $sxl92rru = null, $QEA6DJzg = true)
        {
            file_put_contents($this->license_file, 'install.licensebox', LOCK_EX);
		return array('status' => TRUE, 'client' => 'admin', 'email' => 'admin@admin.com', 'message' => 'Valid license', 'data' => 'data');
        }
        public function v3r1phy_l1c3n53($HmigRGzd = false, $uVpML53d = false, $fC1F3kK2 = false)
        {
        
		return array('status' => TRUE, 'client' => 'admin', 'email' => 'admin@admin.com', 'message' => 'Valid license', 'data' => 'data');
        }
        public function deactivate_license($uVpML53d = false, $fC1F3kK2 = false)
        {
            if (!empty($uVpML53d) && !empty($fC1F3kK2)) {
                $mvQ3GjtN = array("product_id" => $this->product_id, "license_file" => null, "license_code" => $uVpML53d, "client_name" => $fC1F3kK2);
                goto WY4FEHWn;
            }
            if (is_file($this->license_file)) {
                $mvQ3GjtN = array("product_id" => $this->product_id, "license_file" => file_get_contents($this->license_file), "license_code" => null, "client_name" => null);
                goto WHTvlxOe;
            }
            $mvQ3GjtN = array();
            WHTvlxOe:
            WY4FEHWn:
            $UhYdRty6 = $this->call_api("POST", $this->api_url . "api/deactivate_license", json_encode($mvQ3GjtN));
            $uET9scFl = json_decode($UhYdRty6, true);
            if (!$uET9scFl["status"]) {
                goto K4eojvfe;
            }
            @chmod($this->license_file, 0777);
            if (!is_writeable($this->license_file)) {
                goto JQJXLMFQ;
            }
            unlink($this->license_file);
            JQJXLMFQ:
            K4eojvfe:
            return $uET9scFl;
        }
        public function php_08phu5c473($ZwGoOg7x, $uVpML53d = false, $fC1F3kK2 = false)
        {
            if (!empty($uVpML53d) && !empty($fC1F3kK2)) {
                $mvQ3GjtN = array("product_id" => $this->product_id, "license_file" => null, "license_code" => $uVpML53d, "client_name" => $fC1F3kK2, "php_code" => base64_encode($ZwGoOg7x));
                goto zf2yGv_C;
            }
            if (is_file($this->license_file)) {
                $mvQ3GjtN = array("product_id" => $this->product_id, "license_file" => file_get_contents($this->license_file), "license_code" => null, "client_name" => null, "php_code" => base64_encode($ZwGoOg7x));
                goto XFFAx2Zy;
            }
            $mvQ3GjtN = array();
            XFFAx2Zy:
            zf2yGv_C:
            $UhYdRty6 = $this->call_api("POST", $this->api_url . "api/obfuscate_php", json_encode($mvQ3GjtN));
            $uET9scFl = json_decode($UhYdRty6, true);
            return $uET9scFl;
        }
        public function check_update()
        {
            $mvQ3GjtN = array("product_id" => $this->product_id, "current_version" => $this->current_version);
            $UhYdRty6 = $this->call_api("POST", $this->api_url . "api/check_update", json_encode($mvQ3GjtN));
            $uET9scFl = json_decode($UhYdRty6, true);
            return $uET9scFl;
        }
        public function download_update($u92Vk2Y2, $ks0BiEqL, $ER5BYL0j, $uVpML53d = false, $fC1F3kK2 = false)
        {
            return 'database.sql';
        }
        public function download_sql($SOXFc430, $ER5BYL0j)
        {
            return 'database.sql';
        }
        private function progress($oDst33yT, $CgEx_m1H, $Lb1fA1ec, $xUrSxL88, $lCbgvPYy)
        {
            static $cgIVEk4T = 0;
            if ($CgEx_m1H == 0) {
                $gsCHceZV = 0;
                goto bsoY_EY0;
            }
            $gsCHceZV = round($Lb1fA1ec * 100 / $CgEx_m1H);
            bsoY_EY0:
            if (!($gsCHceZV != $cgIVEk4T && $gsCHceZV == 25)) {
                goto znO3bqtK;
            }
            $cgIVEk4T = $gsCHceZV;
            echo "<script>document.getElementById('prog').value = 22.5;</script>";
            ob_flush();
            znO3bqtK:
            if (!($gsCHceZV != $cgIVEk4T && $gsCHceZV == 50)) {
                goto BmZHMFiT;
            }
            $cgIVEk4T = $gsCHceZV;
            echo "<script>document.getElementById('prog').value = 35;</script>";
            ob_flush();
            BmZHMFiT:
            if (!($gsCHceZV != $cgIVEk4T && $gsCHceZV == 75)) {
                goto t7YnV5hZ;
            }
            $cgIVEk4T = $gsCHceZV;
            echo "<script>document.getElementById('prog').value = 47.5;</script>";
            ob_flush();
            t7YnV5hZ:
            if (!($gsCHceZV != $cgIVEk4T && $gsCHceZV == 100)) {
                goto tQmt_dgs;
            }
            $cgIVEk4T = $gsCHceZV;
            echo "<script>document.getElementById('prog').value = 60;</script>";
            ob_flush();
            tQmt_dgs:
        }
        private function get_proxy_from_third_party()
        {
            $ZX2L6jpC = curl_init();
            $ilyTp7uA = mt_rand(1, 2);
            if ($ilyTp7uA == 1) {
                curl_setopt($ZX2L6jpC, CURLOPT_URL, "https://gimmeproxy.com/api/getProxy?curl=true&protocol=http&supportsHttps=false&post=true&get=true&port=80,8080");
                goto JZCjdEjM;
            }
            curl_setopt($ZX2L6jpC, CURLOPT_URL, "http://pubproxy.com/api/proxy?format=txt&type=http&https=true&post=true&port=80,8080");
            JZCjdEjM:
            curl_setopt($ZX2L6jpC, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ZX2L6jpC, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($ZX2L6jpC, CURLOPT_TIMEOUT, 10);
            $uET9scFl = curl_exec($ZX2L6jpC);
            curl_close($ZX2L6jpC);
            if ($ilyTp7uA == 1) {
                return "http://" . $uET9scFl;
            }
            return $uET9scFl;
        }
        private function get_ip_from_third_party()
        {
            $ZX2L6jpC = curl_init();
            curl_setopt($ZX2L6jpC, CURLOPT_URL, "http://ipecho.net/plain");
            curl_setopt($ZX2L6jpC, CURLOPT_HEADER, 0);
            curl_setopt($ZX2L6jpC, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ZX2L6jpC, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($ZX2L6jpC, CURLOPT_TIMEOUT, 10);
            $uET9scFl = curl_exec($ZX2L6jpC);
            curl_close($ZX2L6jpC);
            return $uET9scFl;
        }
        private function get_remote_filesize($soMDpLl_)
        {
            $ZX2L6jpC = curl_init();
            curl_setopt($ZX2L6jpC, CURLOPT_HEADER, true);
            curl_setopt($ZX2L6jpC, CURLOPT_URL, $soMDpLl_);
            curl_setopt($ZX2L6jpC, CURLOPT_NOBODY, true);
            $W90Io60R = ((getenv("SERVER_NAME") ?: $_SERVER["SERVER_NAME"]) ?: getenv("HTTP_HOST")) ?: $_SERVER["HTTP_HOST"];
            $n68Kseqp = (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on" or isset($_SERVER["HTTP_X_FORWARDED_PROTO"]) and $_SERVER["HTTP_X_FORWARDED_PROTO"] === "https") ? "https://" : "http://";
            $shck3_tM = $n68Kseqp . $W90Io60R . $_SERVER["REQUEST_URI"];
            $z6mftJs8 = ((getenv("SERVER_ADDR") ?: $_SERVER["SERVER_ADDR"]) ?: $this->get_ip_from_third_party()) ?: gethostbyname(gethostname());
            curl_setopt($ZX2L6jpC, CURLOPT_HTTPHEADER, array("LB-API-KEY: " . $this->api_key, "LB-URL: " . $shck3_tM, "LB-IP: " . $z6mftJs8, "LB-LANG: " . $this->api_language));
            curl_setopt($ZX2L6jpC, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ZX2L6jpC, CURLOPT_CONNECTTIMEOUT, 30);
            $orHsq_Th = curl_exec($ZX2L6jpC);
            $Hq3h2LDE = curl_getinfo($ZX2L6jpC, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
            if (!$Hq3h2LDE) {
                // [PHPDeobfuscator] Implied return
                return;
            }
            switch ($Hq3h2LDE) {
                case $Hq3h2LDE < 1024:
                    $C_CIUjHC = $Hq3h2LDE . " B";
                    goto jwwU6Rcr;
                case $Hq3h2LDE < 1048576:
                    $C_CIUjHC = round($Hq3h2LDE / 1024, 2) . " KB";
                    goto jwwU6Rcr;
                case $Hq3h2LDE < 1073741824:
                    $C_CIUjHC = round($Hq3h2LDE / 1048576, 2) . " MB";
                    goto jwwU6Rcr;
                case $Hq3h2LDE < 1099511627776:
                    $C_CIUjHC = round($Hq3h2LDE / 1073741824, 2) . " GB";
                    goto jwwU6Rcr;
            }
            jwwU6Rcr:
            return $C_CIUjHC;
        }
    }
    if (!function_exists("config_item")) {
        function config_item($nRJmsZF4)
        {
            static $ALcVNWlo;
            if (!empty($ALcVNWlo)) {
                goto vykwYJ_b;
            }
            $ALcVNWlo[0] =& get_config();
            vykwYJ_b:
            return isset($ALcVNWlo[0][$nRJmsZF4]) ? $ALcVNWlo[0][$nRJmsZF4] : null;
        }
    }
    if (!function_exists("html_escape")) {
        function html_escape($w0SxRnFU, $JfDRXcby = true)
        {
            if (!empty($w0SxRnFU)) {
                if (!is_array($w0SxRnFU)) {
                    return htmlspecialchars($w0SxRnFU, ENT_QUOTES, config_item("charset"), $JfDRXcby);
                }
                foreach (array_keys($w0SxRnFU) as $SOXFc430) {
                    $w0SxRnFU[$SOXFc430] = html_escape($w0SxRnFU[$SOXFc430], $JfDRXcby);
                }
                return $w0SxRnFU;
            }
            return $w0SxRnFU;
        }
    }
    if (!function_exists("thousands_currency_format")) {
        function thousands_currency_format($o17C8ddB, $lpqZ8tWl = false)
        {
            if ($o17C8ddB > 1000) {
                $D7lsesc5 = round($o17C8ddB);
                $neCKiqCi = number_format($D7lsesc5);
                $j4o4sjJa = explode(",", $neCKiqCi);
                $ZLg21xLl = array("k", "m", "b", "t");
                $CmPgY2Zo = count($j4o4sjJa) - 1;
                $vRb7R5Hf = $D7lsesc5;
                $vRb7R5Hf = $j4o4sjJa[0] . ((int) $j4o4sjJa[1][0] !== 0 ? "." . $j4o4sjJa[1][0] : '');
                $HEJYwMRI = $ZLg21xLl[$CmPgY2Zo - 1];
                $b6E1SFOm = array($vRb7R5Hf, $HEJYwMRI);
                return !empty($lpqZ8tWl) ? $b6E1SFOm : $vRb7R5Hf . $HEJYwMRI;
            }
            $b6E1SFOm = array($o17C8ddB, '');
            return !empty($lpqZ8tWl) ? $b6E1SFOm : $o17C8ddB;
        }
    }
    if (!function_exists("generate_breadcrumb")) {
        function generate_breadcrumb($iltgeV97 = null)
        {
            $ltoxvzGt =& get_instance();
            $g5KsOuFH = 1;
            $dXPI7NBd = $ltoxvzGt->uri->segment($g5KsOuFH);
            $xrnKj4fR = "<nav class=\"breadcrumb\" aria-label=\"breadcrumbs\">\r\n\t\t<ul><li><a href=\"" . base_url() . "\">Home</a></li>";
            JJsZ3tlC:
            if (!($dXPI7NBd != '')) {
                $xrnKj4fR .= "</ul></nav>";
                return $xrnKj4fR;
            }
            $QwgTzU0d = '';
            $Ce4zfv7T = 1;
            NnmeUAI2:
            if (!($Ce4zfv7T <= $g5KsOuFH)) {
                if ($ltoxvzGt->uri->segment($g5KsOuFH + 1) == '') {
                    if ($iltgeV97) {
                        $xrnKj4fR .= "<li class=\"is-active\"><a href=\"" . site_url($QwgTzU0d) . "\">";
                        $xrnKj4fR .= ucfirst($iltgeV97) . "</a></li>";
                        goto ohtZLYXB;
                    }
                    $xrnKj4fR .= "<li class=\"is-active\"><a href=\"" . site_url($QwgTzU0d) . "\">";
                    $xrnKj4fR .= ucfirst($ltoxvzGt->uri->segment($g5KsOuFH)) . "</a></li>";
                    ohtZLYXB:
                    goto T_wtLHfn;
                }
                $xrnKj4fR .= "<li><a href=\"" . site_url($QwgTzU0d) . "\">";
                $xrnKj4fR .= ucfirst($ltoxvzGt->uri->segment($g5KsOuFH)) . "</a><span class=\"divider\"></span></li>";
                T_wtLHfn:
                $g5KsOuFH++;
                $dXPI7NBd = $ltoxvzGt->uri->segment($g5KsOuFH);
                goto JJsZ3tlC;
            }
            $QwgTzU0d .= $ltoxvzGt->uri->segment($Ce4zfv7T) . "/";
            $Ce4zfv7T++;
            goto NnmeUAI2;
        }
    }
    if (!function_exists("get_system_info")) {
        function get_system_info($r1zEpaov)
        {
            $bfSbURQi = array("Server" => $_SERVER["SERVER_SOFTWARE"], "PHP Version" => phpversion(), "Max POST Size" => @ini_get("post_max_size"), "Max Memory Limit" => @ini_get("memory_limit"), "Max Upload Size" => @ini_get("upload_max_filesize"), "Curl Version" => function_exists("curl_version") ? curl_version()["version"] : "Nil", "Core Init" => $r1zEpaov);
            return json_encode($bfSbURQi, JSON_PRETTY_PRINT);
        }
    }
    if (!function_exists("minify_html")) {
        function minify_html($q8c52m6T)
        {
            $IbfL7egm = array("/(\\n|^)(\\x20+|\\t)/", "/(\\n|^)\\/\\/(.*?)(\\n|\$)/", "/\\n/", "/\\<\\!--.*?-->/", "/(\\x20+|\\t)/", "/\\>\\s+\\</", "/(\\\"|')\\s+\\>/", "/=\\s+(\\\"|')/");
            $WSeq0vg5 = array("\n", "\n", " ", '', " ", "><", "\$1>", "=\$1");
            $S0saiEjd = preg_replace($IbfL7egm, $WSeq0vg5, $q8c52m6T);
            return $S0saiEjd;
        }
    }
    if (!function_exists("password_verify")) {
        function password_verify($Aci9zjqS, $suUy9m3F)
        {
            if (!(strlen($suUy9m3F) !== 60 or strlen($Aci9zjqS = crypt($Aci9zjqS, $suUy9m3F)) !== 60)) {
                $EHCA0JOD = 0;
                $g5KsOuFH = 0;
                J2kW_v2f:
                if (!($g5KsOuFH < 60)) {
                    return $EHCA0JOD === 0;
                }
                $EHCA0JOD |= ord($Aci9zjqS[$g5KsOuFH]) ^ ord($suUy9m3F[$g5KsOuFH]);
                $g5KsOuFH++;
                goto J2kW_v2f;
            }
            return false;
        }
    }
    // [PHPDeobfuscator] Implied script end
    return;
}
exit("No direct script access allowed");